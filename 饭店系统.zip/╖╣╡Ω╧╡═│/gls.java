public class gls {
   public static void main(String args[]) {
       ZWindow win = new ZWindow();
   }   
}
