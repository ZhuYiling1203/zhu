public class zyl{
   public static void main(String args[]) {
       Denglu denglu = new Denglu();
       
   }   
}